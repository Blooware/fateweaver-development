const AWS = require('aws-sdk');
const s3 = new AWS.S3();
const moment = require('moment');
const fileType = require('file-type');
const sha1 = require('sha1');

var base64json = require('base64json');

var base64 = require('file-base64');

var mysql = require('mysql');

var connection = mysql.createConnection({
    host: 'blootest.c2qh4vkdvsoy.eu-west-2.rds.amazonaws.com',
    user: 'blooware',
    password: 'blooware18',
    port: 3306
});


exports.handler = (event, context, callback) => {
    /*
    callback(null, event);


    var base64String = 'swesh523sfsfgwg';
    base64.decode(base64String, 'text.new.txt', function (err, output) {
        console.log('success');
    });
    //let decoded = base64json.parse(event.base64String);
    */


    //let request = event.body;
    let base64String = event.base64String;
    let buffer = new Buffer(base64String, 'base64');
    let fileMime = fileType(buffer);

    if (fileMime === null) {
        return context.fail('The string suppplied is not a file type');
    }

    let file = getFile(fileMime, buffer);
    let params = file.params;

    var fileStuff = file;

    s3.putObject(params, function (err, data) {
        if (err) {
            console.log(params);
            return console.log(err);
        }
    });


}

let getFile = function (fileMime, buffer) {
    let fileExt = fileMime.ext;
    let hash = sha1(new Buffer(new Date().toString()));
    let now = moment().format('YYY - MM - DD HH: mm: ss');

    let fileName = hash + '.' + fileExt;
    let fileFullName = fileName;
    let fileFullPath = 'bucket name' + fileFullName;

    let params = {
        Bucket: 'fateweaver-admin/portal/temp',
        Key: fileFullName,
        Body: buffer
    };

    let uploadFile = {
        size: buffer.toString('ascii').length,
        type: fileMime.mime,
        name: fileName,
        full_path: fileFullPath
    };

    return {
        'params': params,
        'uploadFile': uploadFile
    };


}