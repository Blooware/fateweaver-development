'use strict'

var mysql = require('mysql');
var connection = mysql.createConnection({
    host: 'blootest.c2qh4vkdvsoy.eu-west-2.rds.amazonaws.com',
    user: 'blooware',
    password: 'blooware18',
    port: 3306
});

exports.handler = (event, context, callback) => {
    console.log(event);
    //stuff
    var data = {
        age: "20",
        info: "Is super cool",
        name: "John",
        tutorGroup: "C1",
    }
    /*
    connection.query("select * from fateweaver.students where name = ? and info = ? and age = ? ", [], function (err, results, fields) {
        if (err) {
            console.log("Error getting tutor groups:", err);
        }
    });

    connection.query("update set ? where ?", [], function (err, results, fields) {
        if (err) {
            console.log("Error getting tutor groups:", err);
        }
    });
    */



}








//john was here